Team Bobby Tables

# BobbyTables

1. run javac -cp .:junit-4.12.jar:hamcrest-core-1.3.jar MainTester.java
2. run java -cp .:junit-4.12.jar:hamcrest-core-1.3.jar org.junit.runner.JUnitCore MainTester 
